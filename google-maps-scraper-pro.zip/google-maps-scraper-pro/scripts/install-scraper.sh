sudo apt install -y python3-pip
python3 -m pip install bota
python3 -m bota install-scraper --repo-url https://github.com/omkarcloud/google-maps-scraper
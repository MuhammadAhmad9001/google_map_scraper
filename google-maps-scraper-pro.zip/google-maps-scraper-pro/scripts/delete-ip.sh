python3 -m pip install bota
python3 -m bota delete-ip --name gmaps --force
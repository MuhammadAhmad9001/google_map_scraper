const Messages = {
  EMAIL_IN_VALID: 'Please enter a valid email address.',
}

export default Messages
